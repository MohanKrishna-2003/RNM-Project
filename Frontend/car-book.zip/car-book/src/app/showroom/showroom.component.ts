import { Component } from '@angular/core';

@Component({
  selector: 'app-showroom',
  imports: [],
  templateUrl: './showroom.component.html',
  styleUrl: './showroom.component.css'
})
export class ShowroomComponent {

}
