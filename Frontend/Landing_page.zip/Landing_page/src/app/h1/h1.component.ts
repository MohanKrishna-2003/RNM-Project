import { Component } from '@angular/core';

@Component({
  selector: 'app-h1',
  standalone:true,
  templateUrl: './h1.component.html',
  styleUrl: './h1.component.css'
})
export class H1Component {

}
